class LocalFilePlayer {
    public void playLocalFile(String filename) {
        System.out.println("Playing local file: " + filename);
    }
}
