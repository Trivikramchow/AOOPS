interface MusicSource {
    void play();
}
