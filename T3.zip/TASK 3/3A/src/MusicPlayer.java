interface MusicPlayer {
    void play();
}
