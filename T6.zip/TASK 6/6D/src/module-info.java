/**
 * 
 */
/**
 * 
 */
module lab_6d {
}