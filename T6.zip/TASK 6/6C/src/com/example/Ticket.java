package com.example;

public class Ticket {
	    private java.lang.String description;

	    public Ticket(java.lang.String description) {
	        this.description = description;
	    }

	    public java.lang.String getDescription() {
	        return description;
	    }
	}