/**
 * 
 */
/**
 * 
 */
module lab_6c {
}