/**
 * 
 */
/**
 * 
 */
module lab_6a {
}