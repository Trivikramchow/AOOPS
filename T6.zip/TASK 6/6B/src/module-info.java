/**
 * 
 */
/**
 * 
 */
module lab_6b {
}