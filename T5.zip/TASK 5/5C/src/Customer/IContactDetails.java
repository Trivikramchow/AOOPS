package Customer;

public interface IContactDetails {
    public String getName();
    public String getMobileNo();
}
