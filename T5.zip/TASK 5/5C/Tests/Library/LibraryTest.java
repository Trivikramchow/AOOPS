package Library;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class LibraryTest {

    @Test
    void lendBook() {
    }

    @Test
    void receiveBook() {
    }
}