package Employee;

public interface IEmployee {
    public String getEmployeeName();
    public String getEmployeeId();
    public String getEmployeeRole();
    public String getEmployeeSalary();
}
