package Salary;

public interface ISalary {
    public void calculateSalary();
    public String formatSalary();
}
