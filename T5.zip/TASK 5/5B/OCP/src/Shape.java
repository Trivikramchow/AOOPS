public interface Shape {
    public void calculateArea();
}
