public class Human implements Works, Eats{
    public void work(){
        System.out.println("Human Works");
    }
    public void eats(){
        System.out.println("Human Eats");
    }
}
