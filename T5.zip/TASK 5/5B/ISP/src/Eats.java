public interface Eats {
    public void eats();
}
