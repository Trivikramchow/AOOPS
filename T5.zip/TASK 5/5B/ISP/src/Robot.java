public class Robot implements Works{
    public void work(){
        System.out.println("Robot Works");
    }
}
