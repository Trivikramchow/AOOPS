public interface Works {
    public void work();
}
