public class Bird implements Flyable{
    public void fly(){
        System.out.println("Flying");
    }
}
