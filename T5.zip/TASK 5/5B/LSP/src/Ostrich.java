public class Ostrich extends Bird{
    public void fly(){
        throw new UnsupportedOperationException("Ostrich Cannot Fly");
    }
}
