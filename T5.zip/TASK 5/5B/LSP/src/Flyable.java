public interface Flyable {
    public void fly();
}
