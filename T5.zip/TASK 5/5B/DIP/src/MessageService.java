public interface MessageService {
    public void sendMessage(String message, String recipient);
}
