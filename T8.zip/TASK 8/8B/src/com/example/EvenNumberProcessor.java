package com.example;

public class EvenNumberProcessor {
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }

    public static int doubleNumber(int number) {
        return number * 2;
    }
}